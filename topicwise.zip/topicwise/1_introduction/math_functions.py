#!/usr/bin/python

#Methods with numbers

import math

# to print absolute value
print("abs(-45) :" , abs(-45))

# to print smallest integer not less than -45.17
print("math.ceil(-34.23) :", math.ceil(-34.23))

#to print exponential of -45.17
print("math.exp(-45.17) :", math.exp(-45.17))

# to print absolute value
print("math.fabs(-45.17) :", math.fabs(-45.17))

# to print largest of its arguments
print("max(80,100,1000) :", max(80,100,1000))

# to print smallest of its arguments
print("min(80,100,1000) :", min(80,100,1000))

# to print value of 100 power of 2
print("math.pow(100,2) :", math.pow(100,2))

# to print rounded to 3 digits
print("round(80.34343,3) :", round(80.34343,3))

# to print square root
print("math.sqrd(100) :", math.sqrt(100))



