#displaying calendar
import calendar
   
cal = calendar.month(2016, 1)
print("Here is the calendar:")
print(cal)
 
