

# Exceptions :  errors that during the runtime or execution time
#                are called as exceptions

 
#But what about division by zero?
a = int(input('First number, please: '))
b = int(input('Second number: '))
print('Your result is ', a/b)
 
